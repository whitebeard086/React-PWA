const u=e=>(e==null?void 0:e.length)===0?0:(e==null?void 0:e.reduce((l,c)=>l+(c==null?void 0:c.rating),0))/(e==null?void 0:e.length);export{u as c};
