import{a1 as i,j as p,a2 as e}from"./index-a992da42.js";const c=(t,o,a,s=5e3)=>{i.push(p.jsx(e,{title:t,type:a,duration:s,children:o}),{placement:"top-center"})};export{c as p};
